import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const file=path.join(__dirname,'../../data/db.json');
const empty={users:[],transactions:[],budgets:[],goals:[]};
export async function readDB(){try{return JSON.parse(await fs.readFile(file,'utf8'));}catch{await writeDB(empty);return structuredClone(empty);}}
export async function writeDB(data){await fs.writeFile(file,JSON.stringify(data,null,2));}
